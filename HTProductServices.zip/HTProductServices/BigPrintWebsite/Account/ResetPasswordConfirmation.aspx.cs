﻿using System.Web.UI;

namespace BigPrintWebsite.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}