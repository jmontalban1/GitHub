﻿using System;

namespace Northwind.Data.Entities
{
    internal class TableAttribute : Attribute
    {
    }
}